package FFSSM;

public enum GroupeSanguin {
	APLUS, AMOINS, BPLUS, BMOINS	
}
